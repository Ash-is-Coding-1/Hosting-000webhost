<?php

    $conn = mysqli_connect('localhost', 'your_username', 'your_password', 'database_name');

    if(!$conn){
        echo "Error Connecting DataBase. Try Again...";
    }
    else{
        echo "DataBase Connected Successfully...";

        if(isset($_POST['submit'])){
            $username = $_POST['username'];
            $email = $_POST['email'];
            $phonenumber = $_POST['phonenumber'];
            $password = $_POST['password'];
            $conpassword = $_POST['conpassword'];

            if($password != $conpassword){
                echo "Password didn't match...";
                exit(0);
            }

            if(strlen($phonenumber) != 10){
                echo'Invalid Phone Number...';
                exit(0);
            }

            $query = "INSERT INTO form_details (username, email, phonenumber, password) VALUES('$username', '$email', '$phonenumber', '$password' )";

            $result = mysqli_query($conn, $query);

            if(!$result){
                echo"Error Occured Try Again...";
            }
            else{
                echo"Data Inserted Successfully...";
            }
 

        }
    }

?>